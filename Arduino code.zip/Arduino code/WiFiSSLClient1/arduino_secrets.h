#define SECRET_SSID "dlink-F434"//"Get-2G-9315CC"//"dlink-F434"//"Get-2G-9315CC" //"Ola's Galaxy A52s "
#define SECRET_PASS  "ymgqq28732"//"ctymnzm2qd"//"ymgqq28732"// //"dsmf3109"
