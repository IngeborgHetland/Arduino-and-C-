﻿namespace DeepoceanLARS
{
    public class MessageEventHandler
    {
    }
}